أماناتي - مشروع تطبيق أندرويد

هذا مشروع Android Studio يغلّف تطبيق أماناتي المحلي داخل تطبيق Android (WebView).
المتطلبات لبناء APK:
- Android Studio حديث
- تثبيت Android SDK Platform 35 عند الطلب
- اتصال بالإنترنت أثناء أول بناء لتنزيل Gradle والمكونات

طريقة البناء:
1) فك ضغط AmanatiAndroid.zip على الكمبيوتر.
2) افتح Android Studio ثم Open واختر مجلد AmanatiAndroid.
3) انتظر Gradle Sync. وافق على تثبيت SDK 35 إذا طُلب.
4) من القائمة Build > Build Bundle(s) / APK(s) > Build APK(s).
5) بعد البناء اختر Locate، وستجد APK غالبًا في app/build/outputs/apk/debug/app-debug.apk.
6) انقل APK إلى الهاتف، افتحه، ووافق على Install unknown apps إذا طلب Android.

مهم:
- التطبيق يحفظ البيانات محليًا على نفس الجهاز. لا تحذف التطبيق أو بياناته قبل عمل نسخة احتياطية من داخل البرنامج.
- هذا المشروع ليس APK جاهزًا؛ بيئة إنشاء الملفات الحالية لا تحتوي على Android SDK/Gradle لتجميع ملف APK.
